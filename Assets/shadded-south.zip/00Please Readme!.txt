Shadded South.ttf, is an original design of southype, is free for personal and non-profit use.

Help my work, all donations are greatly appreciated. paypal:southype@gmail.com

For any commercial use:  http://www.southype.com/Commerce/product/shadded-south/

Please help me with a like in the facebook page https://www.facebook.com/southype

Thank you for downloading my work :)

Saludos desde South America ;)